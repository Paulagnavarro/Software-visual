import React, {useState} from 'react'
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css'

function App() {
  const [currentPage]
  return (
    <div className="App">
      <nav className="navbar navbar-expand-lg navbar-light bg-primary">
        <a className="navbar-brand" href="#">Titulo principal</a>
        <div className="collapse navbar-collapse">
          <ul className="navbar-nav ms-auto">
            <li className="nav-item">
              <button className="nav-link btn" onClick={()=>handleNavClick('createAccount')}>Criar conta</button>
            </li>
            <li className="nav-item">
              <button className="nav-link btn" onClick={()=>handleNavClick('login')}>Login</button>
            </li>
            <li className="nav-item">
              <button className="nav-link btn" onClick={()=>handleNavClick('logout')}>Sair</button>
            </li>
          </ul>
        </div>
      </nav>
      <div className='conteiner text-center mt-5'>
        {currentPage === 'landing' && (
          <div className="mt-4">
            <h1 className="display-4">Segundo bimestre</h1>
          </div>   
        )}
      </div>
      {currentPage === 'createAccount' && (
          <div className="mt-4">
            <div></div>
          </div>   
        )}
         {currentPage === 'logout' && (
          <div className="mt-4">
            <div></div>
          </div>   
        )}
    </div>
  );
}

export default App;
